// var CommonConfig = {
//     version: "1.1",
// };



// module.exports = CommonConfig; 
miCfg.GameConfig = {
    version: "1.5",

};
