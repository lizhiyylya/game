/**
 * Created by xiaochuntian on 2018/5/2.
 */
window.miFrame = {}