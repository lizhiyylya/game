
cc.Class({
    extends: cc.Component,

    properties: {

        uiType : 2,
        uiName : "RichestModel",
    },

    onLoad: function () {
       
    },

    start : function () {
        
    },

    update: function (dt) {

    },

});
