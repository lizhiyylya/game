miDB.ENUM = {
    
}