miDB.GuidData ={    // 引导标记
    
    UEState : "plant",

    isShopOpen : false,
    isFeedOpen :false,
    isGuidBoss:false,
    isFistTurnTable:false
};

miDB.user ={
    isNewUser:"oldUser", 
}
