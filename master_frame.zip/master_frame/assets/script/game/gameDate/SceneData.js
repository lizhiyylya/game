miDB.SceneData = {
    index: 0,
    currPage: 0, //0-怪兽页面，1-升级页面
};