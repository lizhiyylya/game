window.miCfg = {}
window.miTools = {}