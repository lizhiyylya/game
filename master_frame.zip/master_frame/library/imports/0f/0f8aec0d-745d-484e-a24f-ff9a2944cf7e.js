"use strict";
cc._RF.push(module, '0f8aewNdF1ITqJP/5opRM9+', 'BulidMenuModel');
// script/game/game/model/BulidMenuModel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.rootNode = undefined;
    },
    setOwner: function setOwner(node) {
        this.rootNode = node;
    },
    start: function start() {},

    reFreshUI: function reFreshUI(buildData) {
        cc.find("levelLabel", this.node).getComponent(cc.Label).string = "Lv" + buildData.level;
        cc.find("priceLabel", this.node).getComponent(cc.Label).string = "" + miTools.Utils.toLabelString(buildData.buildPrice);
        cc.find("timeProductLabel", this.node).getComponent(cc.Label).string = miTools.Utils.toLabelString(buildData.onceProductCorn) + "/秒";
        cc.find("storeCornLabel", this.node).getComponent(cc.Label).string = "" + miTools.Utils.toLabelString(buildData.storageCorn);
        cc.find("gainLabel", this.node).getComponent(cc.Label).string = "增益+" + buildData.gain;
    },

    update: function update(dt) {},

    removeBuildBtnCallback: function removeBuildBtnCallback() {
        this.node.parent.getComponent("OneBulidingModel").removeBuildBtnCallback();
    },
    updateBuildingBtnCallback: function updateBuildingBtnCallback() {
        this.node.parent.getComponent("OneBulidingModel").updateBuildingBtnCallback({}, 1);
    },
    gainBuildingBtnCallback: function gainBuildingBtnCallback() {
        this.node.parent.getComponent("OneBulidingModel").gainCornByBuildingIdx();
    }
});

cc._RF.pop();