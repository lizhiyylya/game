"use strict";
cc._RF.push(module, '151a5tn0hlOkY1SUE0IUJfx', 'ReformAnim');
// script/game/game/model/ReformAnim.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        tywx.NotificationCenter.listen(miDB.EVENT.MONSTER_REFORM_START, this.animStart, this);
    },
    start: function start() {},
    update: function update(dt) {},


    animStart: function animStart(params) {
        // console.log("-----ReformAnimStart-----");
        var alien = this.node.parent.getChildByName("alien");
        alien.active = true;
        var anim = alien.getComponent(cc.Animation);
        var animState = anim.play();
        // 设置循环模式为 Normal
        animState.wrapMode = cc.WrapMode.Normal;
        animState.repeatCount = 1;
    },

    lightAnimStart: function lightAnimStart() {
        // console.log("-----lightAnimStart-----");
        var light = this.node.parent.getChildByName("send");
        light.active = true;
        var anim = light.getComponent(cc.Animation);
        var animState = anim.play();
        animState.wrapMode = cc.WrapMode.Normal;
        animState.repeatCount = 1;
    },

    lightAnimHalf: function lightAnimHalf() {
        // console.log("-----half of lightAnim-----");
        for (var i = 1; i <= miDB.MasterData.getBuildListLength(); i++) {

            if (i >= 10) {
                var anim = this.node.parent.getChildByName("MonsterLayout1").getChildByName("monster" + i).getChildByName("anim").getComponent(cc.Animation);
                if (this.node.parent.getChildByName("MonsterLayout1").active == true) {
                    anim.play();
                }
            } else {
                var _anim = this.node.parent.getChildByName("MonsterLayout").getChildByName("monster" + i).getChildByName("anim").getComponent(cc.Animation);
                if (this.node.parent.getChildByName("MonsterLayout").active == true) {
                    _anim.play();
                }
            }
        }
    },

    lightAnimFinish: function lightAnimFinish(params) {
        // console.log("-----ReformAnimFinish-----");
        this.node.parent.getChildByName("alien").active = false;
        this.node.parent.getChildByName("send").active = false;
        tywx.NotificationCenter.trigger(miDB.EVENT.MONSTER_REFORM_FINISH, { action: "show" });
    },

    onDestroy: function onDestroy() {
        tywx.NotificationCenter.ignore(miDB.EVENT.MONSTER_REFORM_START, this.animStart, this);
    }
});

cc._RF.pop();