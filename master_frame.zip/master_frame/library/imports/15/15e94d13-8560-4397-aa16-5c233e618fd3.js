"use strict";
cc._RF.push(module, '15e940ThWBDl6oWXCM+YY/T', 'cEncodeDecode');
// script/frameWork/miFrame/base/cEncodeDecode.js

"use strict";

/**
 * Created by wangqi on 2018/7/28.
 */

miFrame.EncodeDecode = {

    base64Encode: function base64Encode(input) {

        return tywx.EncodeDecode.base64Encode(input);
    },

    base64Decode: function base64Decode(input) {

        return tywx.EncodeDecode.base64Decode(input);
    },

    utf8Encode: function utf8Encode(string) {

        return tywx.EncodeDecode.utf8Encode(string);
    },

    utf8Decode: function utf8Decode(input) {

        return tywx.EncodeDecode.utf8Decode(input);
    }
};

cc._RF.pop();