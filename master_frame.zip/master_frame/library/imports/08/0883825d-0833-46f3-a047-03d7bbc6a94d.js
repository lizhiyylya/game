"use strict";
cc._RF.push(module, '08838JdCDNG86BHA9e7xqlN', 'hamburger');
// script/game/game/model/hamburger.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        icon: cc.Node
    },

    onCollisionEnter: function onCollisionEnter(other, self) {},

    onCollisionStay: function onCollisionStay(other) {},

    onCollisionExit: function onCollisionExit(other, self) {
        var anim = this.icon.getComponent(cc.Animation);
        if (!anim.isPlay) {
            anim.isPlay = true;
            anim.play("hamburger");
            var that = this;
            anim.on('finished', function () {
                if (!anim.isFeed) {
                    anim.isFeed = true;
                    tywx.NotificationCenter.trigger(miDB.EVENT.SUPER_FEED_COUNT, { desc: "超级喂养+1" });
                }
                that.node.destroy();
            }, this);
        }
    },

    onLoad: function onLoad() {},
    start: function start() {},
    update: function update(dt) {},
    onDestroy: function onDestroy() {}
});

cc._RF.pop();