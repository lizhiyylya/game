"use strict";
cc._RF.push(module, '102dc3PuZ9NMb0Z1Yzo6l9r', 'GameConfig');
// script/frameWork/core/GameConfig.js

"use strict";

// var CommonConfig = {
//     version: "1.1",
// };


// module.exports = CommonConfig; 
miCfg.GameConfig = {
    version: "1.5"

};

cc._RF.pop();