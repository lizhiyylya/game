"use strict";
cc._RF.push(module, '52922Ty6E1HVrL7wCqnw/8s', 'HumanModel');
// script/game/game/model/HumanModel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        uiType: 2,
        uiName: "HumanModel",
        richestMan: cc.Node,
        heroAtlas: cc.SpriteAtlas
    },

    onLoad: function onLoad() {
        tywx.NotificationCenter.listen(miDB.EVENT.LAYOUT_GAME_WEATHER, this.wigthLayout, this);
        tywx.NotificationCenter.listen(miDB.EVENT.WECHAT_GAME_GUIDE_HER0, this.actionManger, this);
        var humanSet = cc.find("humanSet", this.node);
        this._createRichest(humanSet);
    },
    actionManger: function actionManger(data) {
        if (data.action == "show" && data.index == 0) {
            this.firstActionCallBack();
        } else if (data.action == "show" && data.index == 1) {
            this.firstAction();
        } else if (data.action == "show" && data.index == 2) {
            this.richestMan.getChildByName("text").getComponent(cc.Label).string = "可以进入新地区建筑建筑了，新的建筑会有意想不到的效果出现哟，快来开启新地区吧！";
            this.secondAction();
        } else if (data.action == "show" && data.index == 3) {
            // this.secondActionCallBack();
            this.richestMan.getChildByName("talk").active = false;
            this.richestMan.getChildByName("text").active = false;
            this.animMove();
        } else if (data.action == "show" && data.index == 4) {
            this.richestMan.getChildByName("text").getComponent(cc.Label).string = "最终的目标终于要达成了，赶快前往东城建造我们最后的乐园吧。";
            this.secondAction();
        } else if (data.action == "show" && data.index == 5) {
            // 改造
            this.richestMan.getChildByName("text").getComponent(cc.Label).string = "终于实现终极目标了，以后就可以炒房赚钱啦！老建筑改造后转化成股票。";
            this.secondAction();
        } else if (data.action == "show" && data.index == 6) {
            // 商店
            this.richestMan.getChildByName("text").getComponent(cc.Label).string = "股票可以在商店中购买更多加速产出的产品。";
            this.secondAction();
        } else if (data.action == "show" && data.index == 7) {
            // 恢复
            this.secondActionCallBack();
        }
    },
    wigthLayout: function wigthLayout(data) {

        //console.log ( data.node.y+ data.node.height/2+ this.node.getChildByName("humanSet").height/2);

        this.node.getChildByName("humanSet").y = data.node.y + data.node.height / 2 + this.node.getChildByName("humanSet").height / 2 + 10;
    },


    _createRichest: function _createRichest(buildset) {
        var that = this;
        var uiName = "RichestModel";
        miTools.Utils.loadPrefab("model/gameModel/shapeModel/" + uiName, function (model) {
            if (model != undefined) {
                //设置层级
                buildset.addChild(model);
                model.active = true;
                that.richestMan = model;

                //that.richestMan.getChildByName("talk").active = true;
                //that.richestMan.getChildByName("talk").on('mousedown', function (event) {
                // that.richestMan.getChildByName("talk").active = false;
                // that.humanMove();
                //})
                var moveTo1 = cc.moveTo(9, -300, 0);
                var moveTo2 = cc.moveTo(9, 300, 0);
                that.walkAction = cc.sequence(cc.callFunc(function () {
                    that.richestMan.rotationY = 180;
                }), moveTo1, cc.callFunc(function () {
                    that.richestMan.rotationY = 0;
                }), moveTo2);

                that.animWalk = that.richestMan.getComponent(cc.Animation);
                // frames 这是一个 SpriteFrame 的数组.
                var frame = [];

                for (var i = 0; i < 8; i++) {
                    var index = "D_0000" + (i + 1);
                    frame.push(that.heroAtlas.getSpriteFrame(index));
                }
                var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
                clip.name = "animal_walk";
                clip.wrapMode = cc.WrapMode.Loop;
                that.animWalk.speed = 0.15;
                that.animWalk.addClip(clip);
                console.log("_createRichest loaded...");
                that.animMove();
            } else {
                tywx.LOGD("加载错误 model = ", uiName);
            }
        });
    },
    firstAction: function firstAction() {
        var that = this;
        that.richestMan.stopAllActions();
        var moveTo = cc.moveTo(0.5, -100, 0);
        that.richestMan.x = -300;
        that.richestMan.rotationY = 0;
        cc.find("humanSet", this.node).active = true;
        that.richestMan.runAction(cc.sequence(cc.callFunc(function () {
            that.animWalk.play('animal_walk');
        }), moveTo, cc.callFunc(function () {
            that.richestMan.getChildByName("talk").active = true;
            that.richestMan.getChildByName("text").active = true;
            that.richestMan.getChildByName("text").getComponent(cc.Label).string = "欢迎来到大亨世界，点击标识牌来跟我一起来建造自己的金钱帝国吧";
            that.richestMan.getChildByName("talk").x = 100;
            that.animWalk.stop();
            miTools.Utils.loadSprite(that.richestMan, miCfg.Building.UIconfigPath.gameAdorn, "sp_human_right");
            //animation.destroy();
            miDB.GuidData.isTouch = true;
        })));
    },
    firstActionCallBack: function firstActionCallBack() {
        var that = this;
        that.richestMan.stopAllActions();
        that.richestMan.getChildByName("talk").active = false;
        that.richestMan.getChildByName("text").active = false;
        var moveTo = cc.moveTo(6, 300, 0);
        that.richestMan.runAction(cc.sequence(cc.callFunc(function () {
            var frame = [];
            for (var i = 0; i < 8; i++) {
                var index = "D_0000" + (i + 1);
                frame.push(that.heroAtlas.getSpriteFrame(index));
            }
            var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
            clip.name = "animal_walk";
            clip.wrapMode = cc.WrapMode.Loop;
            that.animWalk.speed = 0.15;
            that.animWalk.addClip(clip);
            that.animWalk.play('animal_walk');
        }), moveTo, cc.callFunc(function () {
            that.humanMove();
        })));
    },
    secondAction: function secondAction() {
        var that = this;
        that.richestMan.stopAllActions();
        var duration = (200 - that.richestMan.x) / 100 * 0.5;
        var currY = 200;
        if (duration >= 0) {
            that.richestMan.rotationY = 0;
        } else {
            that.richestMan.rotationY = 180;
            duration = -duration;
            currY = 160;
        }
        that.richestMan.runAction(cc.sequence(cc.callFunc(function () {}), cc.moveTo(duration, currY, 0), cc.callFunc(function () {
            that.animWalk.stop();
            that.richestMan.getChildByName("talk").active = true;
            that.richestMan.getChildByName("text").active = true;
            that.richestMan.getChildByName("talk").x = 0;
            that.richestMan.getChildByName("text").x = -130;
            that.richestMan.getChildByName("text").rotationY = 0;
            if (that.richestMan.rotationY == 180) {
                that.richestMan.getChildByName("text").rotationY = 180;
                that.richestMan.getChildByName("text").x = 130;
                miTools.Utils.loadSprite(that.richestMan, miCfg.Building.UIconfigPath.gameAdorn, "sp_human_right");
            } else if (that.richestMan.rotationY == 0) {
                miTools.Utils.loadSprite(that.richestMan, miCfg.Building.UIconfigPath.gameAdorn, "sp_human");
            }
            miDB.GuidData.isTouch = true;
        })));
    },
    secondActionCallBack: function secondActionCallBack() {
        var that = this;
        that.richestMan.stopAllActions();
        that.richestMan.getChildByName("talk").active = false;
        that.richestMan.getChildByName("text").active = false;
        var moveTo = cc.moveTo(1.5, 300, 0);
        that.richestMan.rotationY = 0;
        that.richestMan.runAction(cc.sequence(cc.callFunc(function () {
            var frame = [];
            for (var i = 0; i < 8; i++) {
                var index = "D_0000" + (i + 1);
                frame.push(that.heroAtlas.getSpriteFrame(index));
            }
            var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
            clip.name = "animal_walk";
            clip.wrapMode = cc.WrapMode.Loop;
            that.animWalk.speed = 0.15;
            that.animWalk.addClip(clip);
            that.animWalk.play('animal_walk');
        }), moveTo, cc.callFunc(function () {
            that.humanMove();
        })));
    },
    humanMove: function humanMove() {
        tywx.NotificationCenter.trigger(miDB.EVENT.GUIDE_HIDE_CLICK, {});
        var that = this;
        cc.find("humanSet", this.node).active = true;
        that.richestMan.runAction(that.walkAction).repeatForever();
    },
    animMove: function animMove() {
        var that = this;
        that.richestMan.x = -440;
        that.richestMan.rotationY = 0;
        var moveTo = cc.moveTo(9, 300, 0);
        that.richestMan.runAction(cc.sequence(cc.callFunc(function () {
            cc.find("humanSet", that.node).active = true;
            that.animWalk.play('animal_walk');
        }), moveTo, cc.callFunc(function () {
            that.humanMove();
        })));
    },
    runNormalAction: function runNormalAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 12; i++) {
            var index = "A_0000" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_normal";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_normal');
    },
    runPickAction: function runPickAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 4; i++) {
            var index = "pick_" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_pick";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_pick');
    },
    runDownAction: function runDownAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 6; i++) {
            var index = "down" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_down";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.1;
        animation.addClip(clip);
        animation.play('animal_down');
    },
    runBallAction: function runBallAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 4; i++) {
            var index = "w_" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_w";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_w');
    },
    runStandAction: function runStandAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 7; i++) {
            var index = "B_0000" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_stand";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_stand');
    },
    runCoinAction: function runCoinAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 6; i++) {
            var index = "C_0000" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_coin";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_coin');
    },
    runWalkAction: function runWalkAction() {

        var animation = this.richestMan.getComponent(cc.Animation);
        // frames 这是一个 SpriteFrame 的数组.
        var frame = [];

        for (var i = 0; i < 8; i++) {
            var index = "D_0000" + (i + 1);
            frame.push(this.heroAtlas.getSpriteFrame(index));
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, 10);
        clip.name = "animal_walk";
        clip.wrapMode = cc.WrapMode.Loop;
        animation.speed = 0.15;
        animation.addClip(clip);
        animation.play('animal_walk');
    },


    _runGameAI: function _runGameAI() {
        var moveTo1 = cc.moveTo(1.5, -500, 0);
        var moveTo2 = cc.moveTo(3, 200, 0);
        this.richestMan.runAction(cc.sequence(cc.callFunc(function () {
            // tywx.LOGD("开始")
        }), moveTo1,
        // cc.skewBy(1, 0, 180),
        //cc.rotateBy(0.1, 0, 180),
        moveTo2, cc.callFunc(function () {
            // tywx.LOGD("结束")
        })).repeatForever());
    },
    update: function update(dt) {}

});

cc._RF.pop();