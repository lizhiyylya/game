"use strict";
cc._RF.push(module, '184f7WMrHxF57j3wHZa5ejE', 'RichestModel');
// script/game/game/model/RichestModel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        uiType: 2,
        uiName: "RichestModel"
    },

    onLoad: function onLoad() {},

    start: function start() {},

    update: function update(dt) {}

});

cc._RF.pop();