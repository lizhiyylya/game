"use strict";
cc._RF.push(module, '094a0dDHopPVIKZ2FUL8A0Y', 'test');
// script/game/game/model/test.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},

    show: function show(data) {

        console.log("zzzzz");
    }

    // update (dt) {},
});

cc._RF.pop();