"use strict";
cc._RF.push(module, '4e3acTNCrRDxqKdqw87sLiA', 'ReFormModel');
// script/game/game/model/ReFormModel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        uiType: 2,
        uiName: "ReFormModel"
    },

    // onLoad () {},

    start: function start() {

        this.reshUI();
    },
    quickCall: function quickCall() {
        console.log("quickCall");

        cc.find("cllNode", this.node).active = true;
        cc.find("soldLayout", this.node).active = false;
    },
    reshUI: function reshUI() {
        this.reFromNum = miCfg.Master.getReFromGold();
        cc.find("soldLayout", this.node).active = true;
        cc.find("soldLayout/img/upnum", this.node).getComponent(cc.Label).string = miTools.Utils.toLabelString(this.reFromNum) || 0;
        cc.find("cllNode", this.node).active = false;
        cc.find("resultNode", this.node).active = false;
    },
    show: function show(data) {
        if (typeof this.reFromNum != "undefined") {
            this.reshUI();
        }
    },
    showResult: function showResult() {
        var diamond = miDB.GameData.getItemByName("diamond");
        var isPrice = miTools.Utils.comparedTo(diamond, 50);
        if (isPrice < 0) {
            tywx.NotificationCenter.trigger(miDB.EVENT.SHOW_COMMENT_TIPS, { title: "提示", content: "钻石不足，无法回收！ " });
            return;
        }

        miDB.MasterData.reForm();
        cc.find("cllNode", this.node).active = false;
        cc.find("resultNode", this.node).active = true;
        cc.find("resultNode/resultLayout/title_bg/title", this.node).getComponent(cc.Label).string = "第" + miDB.localData.game.reformNum + "收益";
        cc.find("resultNode/resultLayout/num", this.node).getComponent(cc.Label).string = miTools.Utils.toLabelString(this.reFromNum) + "%";
    },
    closeCall: function closeCall() {
        console.log("closeCall");
        cc.find("cllNode", this.node).active = false;
        cc.find("soldLayout", this.node).active = true;
    },
    close: function close() {
        console.log("close");
        mi.UIManager.hideUI("ReFormModel", { ceng: 50 });
    },
    hide: function hide(data) {
        console.log("hide");
        console.log(data);
    }
}

// update (dt) {},
);

cc._RF.pop();