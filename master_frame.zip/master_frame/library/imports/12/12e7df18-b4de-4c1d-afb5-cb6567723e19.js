"use strict";
cc._RF.push(module, '12e7d8YtN5MHa+1y2Vncj4Z', 'ShitData');
// script/game/gameDate/ShitData.js

"use strict";

miDB.ShitData = {
    TAG: "ShitData",

    timeId: "",
    bossTime: "null",
    init: function init() {

        if (miDB.localData.game.shitNum < 50) {
            if (miDB.ShitData.timeId == "") {
                miDB.ShitData.timeId = setInterval(this.updateBoxtime, 30000);

                this.shitCommit();
            }
        }
    },

    updateBoxtime: function updateBoxtime() {
        if (miDB.localData.game.shitNum >= 50) {
            clearInterval(miDB.ShitData.timeId);
            return;
        }
        if (miDB.localData.game.finshGuid == true && miDB.MasterData.getBuildListLength() > 0 && miDB.localData.game.shitNum < 50 && miDB.localData.shitList.length < 2) {

            tywx.NotificationCenter.trigger(miDB.EVENT.SHIT_DATA_SHOWUI, { action: "new" });
        }
    },
    shitCommit: function shitCommit() {
        // tywx.NotificationCenter.trigger(miDB.EVENT.SHIT_DATA_SHOWUI, {action:"show"}); 
        mi.UIManager.showUI("ShitSystemModel", { ceng: 39 });
    }
};

cc._RF.pop();